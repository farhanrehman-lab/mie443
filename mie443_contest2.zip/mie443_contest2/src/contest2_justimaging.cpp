#include <boxes.h>
#include <navigation.h>
#include <robot_pose.h>
#include <imagePipeline.h>

#include <cmath>

double xGoal = 0;
double yGoal = 0;
double phiGoal = 0;

double distanceArray[6][6];
int orderDestArray[5];
int orderCount = 0;
int visited[5] = {0,0,0,0,0};

double revxGoal = 0;
double revyGoal = 0;
double revphiGoal = 0;
double PI = 1.570795;

void tsp(int start) {
    double minpath = 999; 
    int nextbox = 0;
    
    for (int i = 1; i < 6; i++) {
        if ((distanceArray[start][i] < minpath) && (distanceArray[start][i] != 0) && (visited[i] == 0)) {
            minpath = distanceArray[start][i];
            nextbox = i;
            //visited[i] = 1;
        }
        
    // if ( nextbox == 0)
    // visited[nextbox] = 0;
    }
    visited[nextbox] = 1;
    orderDestArray[orderCount] = nextbox;
    orderCount++;
    std::cout <<"box"<< nextbox<<std::endl;
    if (orderCount == 5) {
        return;
    }
    
    tsp(nextbox);
    
}


int main(int argc, char** argv) {
    // Setup ROS.
    ros::init(argc, argv, "contest2");
    ros::NodeHandle n;
    // Robot pose object + subscriber.
    RobotPose robotPose(0,0,0); 
    ros::Subscriber amclSub = n.subscribe("/amcl_pose", 1, &RobotPose::poseCallback, &robotPose);
    
    while (robotPose.x==0 && robotPose.y==0 && robotPose.phi==0){
        ros::spinOnce();
    }
    float startX = robotPose.x;
    float startY = robotPose.y;
    float startPhi = robotPose.phi;
    // Initialize box coordinates and templates
    Boxes boxes; 
    if(!boxes.load_coords() || !boxes.load_templates()) {
        std::cout << "ERROR: could not load coords or templates" << std::endl;
        return -1;
    }
    for(int i = 0; i < boxes.coords.size(); ++i) {
        std::cout << "Box coordinates: " << std::endl;
        std::cout << i << " x: " << boxes.coords[i][0] << " y: " << boxes.coords[i][1] << " z: " 
                  << boxes.coords[i][2] << std::endl;
    }
    // Initialize image objectand subscriber.
    ImagePipeline imagePipeline(n);
    // Execute strategy.

    FILE * outputFile = fopen("/home/turtlebot/catkin_ws/src/mie443_contest2/src/outputFile.txt", "w");
    
    //Navigation::moveToGoal(-1.404,2.5,-1.606);
    while(ros::ok()) {
        ros::spinOnce();
        /***YOUR CODE HERE***/

        for(int i = 0; i < 5;i++) {
            phiGoal = boxes.coords[i][2] - 2*PI;
            xGoal = boxes.coords[i][0] - 0.5*cos(phiGoal);
            yGoal = boxes.coords[i][1] - 0.5*sin(phiGoal);
            Navigation::moveToGoal(xGoal,yGoal,phiGoal);
            //ros::spinOnce();
            int counter = 0;
            int result = -1;
            do{
                ros::spinOnce();
                result = imagePipeline.getTemplateID(boxes);
                counter ++; 
            } while(counter < 10 && result == -1);

            //std::cout<<"It is  "<< result << std::endl;
            char* answer = "";
            char* duplicate = "";
            int found[4] = {0,0,0,0};
            if(result == 0)
                answer = "Raising Bran";
            else if (result == 1)
                answer = "Cinnamon Crunch";
            else if (result == 2)
                answer = "Rice Crispies";
            else if (result == 3)
                answer = "Blank";
            else 
                answer = "Invalid Read";
            
            found[result] ++;
            if(found[result] == 2)
                duplicate = "duplicate";

            fprintf(outputFile, "The box %d at coordinates (%lf, %lf) is %s %s.\n", i, boxes.coords[i][0], boxes.coords[i][1], answer, duplicate);

            ros::Duration(0.01).sleep();
        
        
        }
        Navigation::moveToGoal(startX,startY,startPhi);
        fclose(outputFile);
        ros::Duration(0.01).sleep();
        break;
        
    }
    return 0;
}
