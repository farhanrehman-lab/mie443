#pragma once

class Navigation {
	public:
		static bool moveToGoal(float xGoal, float yGoal, float phiGoal);
};
